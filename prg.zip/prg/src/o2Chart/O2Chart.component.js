System.register(['angular2/core', '../model/O2Common', '../const/chartConst'], function(exports_1) {
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = (this && this.__param) || function (paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    };
    var core_1, O2Common_1, chartConst_1;
    var O2ChartComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (O2Common_1_1) {
                O2Common_1 = O2Common_1_1;
            },
            function (chartConst_1_1) {
                chartConst_1 = chartConst_1_1;
            }],
        execute: function() {
            O2ChartComponent = (function () {
                function O2ChartComponent(elementRef) {
                    var el = elementRef.nativeElement;
                    this.root = d3.select(el);
                }
                O2ChartComponent.prototype.ngOnInit = function () {
                };
                O2ChartComponent.prototype.ngOnChanges = function (changes) {
                    var svgWidth = parseInt(this.svgWidth);
                    var svgHeight = parseInt(this.svgHeight);
                    var dataSet = this.graphData;
                    var configData = this.configData;
                    var chartType = this.chartType;
                    var svgContainer = this.root.append("svg")
                        .attr("width", svgWidth)
                        .attr("height", svgHeight);
                    switch (chartType) {
                        case chartConst_1.ChartConst.LINE_CHART_TYPE_NAME:
                            this.buildLine(svgContainer, configData, dataSet, svgWidth, svgHeight);
                            break;
                        case chartConst_1.ChartConst.BAR_CHART_TYPE_NAME:
                            this.buildBar(svgContainer, configData, dataSet, svgWidth, svgHeight);
                            break;
                        case chartConst_1.ChartConst.PIE_CHART_TYPE_NAME:
                            this.buildPie(svgContainer, configData, dataSet, svgWidth, svgHeight);
                            break;
                        case chartConst_1.ChartConst.SCATTER_PLOT_CHART_TYPE_NAME:
                            this.buildScatterPlot(svgContainer, configData, dataSet, svgWidth, svgHeight);
                            break;
                        case chartConst_1.ChartConst.HISTOGRAM_CHART_TYPE_NAME:
                            this.buildHistogram(svgContainer, configData, dataSet, svgWidth, svgHeight);
                            break;
                        case chartConst_1.ChartConst.STACK_BAR_CHART_TYPE_NAME:
                            this.buildStackBar(svgContainer, configData, dataSet, svgWidth, svgHeight);
                            break;
                        case chartConst_1.ChartConst.GEO_MAP_CHART_TYPE_NAME:
                            this.buildGeoMap(svgContainer, configData, dataSet, svgWidth, svgHeight);
                            break;
                        case chartConst_1.ChartConst.GEO_ORTHOGRAPHIC_CHART_TYPE_NAME:
                            this.buildGeoOrthographic(svgContainer, configData, dataSet, svgWidth, svgHeight);
                            break;
                        case chartConst_1.ChartConst.TREE_MAP_CHART_TYPE_NAME:
                            this.buildTreeMap(svgContainer, configData, dataSet, svgWidth, svgHeight);
                            break;
                        case chartConst_1.ChartConst.PACK_LAYOUT_CHART_TYPE_NAME:
                            this.buildPackLayout(svgContainer, configData, dataSet, svgWidth, svgHeight);
                            break;
                        case chartConst_1.ChartConst.CHOROPLETH_CHART_TYPE_NAME:
                            this.buildChoropleth(svgContainer, configData, dataSet, svgWidth, svgHeight);
                            break;
                        default:
                            ;
                    }
                };
                //------------------------------------
                //---Build Legend  -------------------
                //------------------------------------
                O2ChartComponent.prototype.buildLegend = function (o2Common, _legendDataSet) {
                    console.log("in buildLegend-------------------");
                    // maxValues are meaningless
                    var cdt = o2Common;
                    var configData = cdt.configData;
                    var svgContainer = cdt.svgContainer;
                    // let cdt = new O2Common(configData,100,100,svgWidth,svgHeight);
                    var legendRectSize = configData.legend.rectWidth;
                    var legendSpacing = 10;
                    var ySpacing = configData.legend.ySpacing;
                    var initPosX = cdt.legendInitXPos;
                    var initPosY = cdt.legendInitYPos;
                    var opacity = configData.color.opacity;
                    var grpLegend = svgContainer.append("g")
                        .selectAll("g")
                        .data(_legendDataSet)
                        .enter()
                        .append("g")
                        .attr("class", "legend")
                        .attr("transform", function (d, i) {
                        var height = legendRectSize + ySpacing;
                        var x = initPosX;
                        var y = i * height + initPosY;
                        return "translate(" + x + ", " + y + ")";
                    });
                    grpLegend.append("rect")
                        .attr("width", legendRectSize)
                        .attr("height", legendRectSize)
                        .style("fill", function (d, i) {
                        return d.color;
                    })
                        .style("stroke", function (d, i) {
                        return d.color;
                    })
                        .attr("fill-opacity", opacity);
                    grpLegend.append("text")
                        .attr("x", legendRectSize + legendSpacing)
                        .attr("y", legendRectSize)
                        .text(function (d, i) {
                        return d.title;
                    });
                };
                //------------------------------------
                //--- drawTitle-----------------
                O2ChartComponent.prototype.drawTitle = function (o2Common) {
                    console.log("in drawTitle-------------------");
                    var cdt = o2Common;
                    var configData = cdt.configData;
                    var svgContainer = cdt.svgContainer;
                    var _title = configData.title.name;
                    var _xPos = cdt.titleInitXPos;
                    var _yPos = cdt.titleInitYPos;
                    var _titleClassName = configData.title.className;
                    svgContainer.append("text")
                        .attr("class", _titleClassName)
                        .attr("x", _xPos)
                        .attr("y", _yPos)
                        .text(_title);
                };
                //------------------------------------
                //---Build Axis  -------------------
                //------------------------------------
                O2ChartComponent.prototype.buildYAxis = function (o2Common) {
                    console.log("in buildYAxis-------------------");
                    var cdt = o2Common;
                    var configData = cdt.configData;
                    var svgContainer = cdt.svgContainer;
                    var _maxY = cdt.maxYValue;
                    var _graphYScale = cdt.graphYScale;
                    var _graphWidth = cdt.graphWidth;
                    var _axisYScale = d3.scale.linear()
                        .domain([0, _maxY])
                        .range([_maxY * _graphYScale, 0]);
                    svgContainer.append("g")
                        .attr("class", cdt.axisClassName)
                        .attr("transform", cdt.axisTranslatePos)
                        .call(d3.svg.axis()
                        .scale(_axisYScale)
                        .orient(cdt.axisYOrient));
                };
                O2ChartComponent.prototype.buildXAxis = function (o2Common) {
                    console.log("in buildXAxis-------------------");
                    var cdt = o2Common;
                    var configData = cdt.configData;
                    var svgContainer = cdt.svgContainer;
                    var _maxX = cdt.maxXValue;
                    var _graphXScale = cdt.graphXScale;
                    var _axisXScale = d3.scale.linear()
                        .domain([0, _maxX])
                        .range([0, _maxX * _graphXScale]);
                    svgContainer.append("g")
                        .attr("class", cdt.axisClassName)
                        .attr("transform", cdt.axisXBorderTranslatePos)
                        .call(d3.svg.axis()
                        .scale(_axisXScale)
                        .orient(cdt.axisXOrient));
                };
                O2ChartComponent.prototype.drawXAxisLabel = function (o2Common, labelDataSet, chartType) {
                    console.log("in drawXAxisLabel-------------------");
                    var cdt = o2Common;
                    var configData = cdt.configData;
                    var svgContainer = cdt.svgContainer;
                    var _maxX = cdt.maxXValue;
                    var _initXPos = cdt.axisXLabelInitXPos;
                    var _initYPos = cdt.axisXLabelInitYPos;
                    var _columnNum = labelDataSet.length;
                    var _columnWidth = cdt.graphWidth / _columnNum;
                    if (chartType == chartConst_1.ChartConst.LINE_CHART_TYPE_NAME) {
                        _columnWidth = cdt.graphWidth / (_columnNum - 1);
                    }
                    var grpLabel = svgContainer.append("g")
                        .selectAll("g")
                        .data(labelDataSet)
                        .enter()
                        .append("g")
                        .attr("class", configData.axisXText)
                        .attr("transform", function (d, i) {
                        var _x = _initXPos + _columnWidth * i;
                        var _y = _initYPos;
                        return "translate(" + _x + ", " + _y + ")";
                    });
                    var textElements = grpLabel.append("text")
                        .attr("class", configData.className.axisXText)
                        .text(function (d, i) {
                        return d;
                    });
                };
                O2ChartComponent.prototype.drawXBaseLine = function (o2Common) {
                    console.log("in drawXBaseLine-------------------");
                    var cdt = o2Common;
                    var svgContainer = cdt.svgContainer;
                    svgContainer.append("rect")
                        .attr("class", cdt.axisXBorderLineClassName)
                        .attr("width", cdt.axisXBorderWidth)
                        .attr("height", cdt.axisXBorderLineWidth)
                        .attr("transform", cdt.axisXBorderTranslatePos);
                };
                O2ChartComponent.prototype.drawSingleLine = function (o2Common, dataSet, lineNum) {
                    console.log("in drawSingleLine-------------------");
                    var cdt = o2Common;
                    var configData = cdt.configData;
                    var svgContainer = cdt.svgContainer;
                    var _maxX = cdt.maxXValue;
                    var _initXPos = cdt.axisXLabelInitXPos;
                    var _initYPos = cdt.axisXLabelInitYPos;
                    var _columnNum = dataSet.length;
                    var _columnWidth = cdt.graphWidth / (_columnNum - 1);
                    var _color = d3.scale.category10();
                    var _lineClassName = configData.className.multiLinePrefix + String(lineNum);
                    var _lineInterpolate = configData.line.interpolate;
                    var _leftMargin = configData.margin.left;
                    var _bottomMargin = configData.margin.bottom;
                    var _yScale = cdt.graphYScale;
                    var line = d3.svg.line()
                        .x(function (d, i) {
                        return _leftMargin + i * _columnWidth;
                    })
                        .y(function (d, i) {
                        return cdt.svgHeight - _bottomMargin - (d * _yScale);
                    })
                        .interpolate(_lineInterpolate);
                    var lineElements = svgContainer.append("path")
                        .attr("class", _lineClassName)
                        .attr("d", line(dataSet));
                    // .attr("transform",cdt.axisTranslatePos)
                };
                //------------------------------------
                //---drawGrid  -------------------
                //------------------------------------
                O2ChartComponent.prototype.drawYGrid = function (o2Common) {
                    console.log("in buildYGrid-------------------");
                    var cdt = o2Common;
                    var configData = cdt.configData;
                    var svgContainer = cdt.svgContainer;
                    var _stepY = cdt.gridYStep;
                    var _maxY = cdt.maxYValue;
                    var _graphYScale = cdt.graphYScale;
                    var _graphXScale = cdt.graphXScale;
                    var _graphWidth = cdt.graphWidth;
                    var _gridClassName = configData.className.grid;
                    var _axisYScale = d3.scale.linear()
                        .domain([0, _maxY])
                        .range([_maxY * _graphYScale, 0]);
                    var _rangeY = d3.range(_stepY * _graphYScale, _maxY * _graphYScale, _stepY * _graphYScale);
                    svgContainer.append("g")
                        .selectAll("line.y")
                        .data(_rangeY)
                        .enter()
                        .append("line")
                        .attr("class", _gridClassName)
                        .attr("x1", configData.margin.left)
                        .attr("y1", function (d, i) {
                        var _y1 = cdt.svgHeight - configData.margin.bottom - d;
                        return _y1;
                    })
                        .attr("x2", configData.margin.left + cdt.axisXBorderWidth)
                        .attr("y2", function (d, i) {
                        var _y1 = cdt.svgHeight - configData.margin.bottom - d;
                        return _y1;
                    });
                };
                O2ChartComponent.prototype.drawXGrid = function (o2Common) {
                    console.log("in buildXGrid-------------------");
                    var cdt = o2Common;
                    var configData = cdt.configData;
                    var svgContainer = cdt.svgContainer;
                    var _stepX = cdt.gridXStep;
                    var _maxX = cdt.maxXValue;
                    var _graphYScale = cdt.graphYScale;
                    var _graphXScale = cdt.graphXScale;
                    var _graphWidth = cdt.graphWidth;
                    var _gridClassName = configData.className.grid;
                    var _axisXScale = d3.scale.linear()
                        .domain([0, _maxX])
                        .range([0, _maxX * _graphXScale]);
                    var _rangeX = d3.range(_stepX * _graphXScale, _maxX * _graphXScale, _stepX * _graphXScale);
                    svgContainer.append("g")
                        .selectAll("line.x")
                        .data(_rangeX)
                        .enter()
                        .append("line")
                        .attr("class", _gridClassName)
                        .attr("x1", function (d, i) {
                        var _x1 = configData.margin.left + d;
                        return _x1;
                    })
                        .attr("y1", cdt.svgHeight - configData.margin.bottom)
                        .attr("x2", function (d, i) {
                        var _x2 = configData.margin.left + d;
                        return _x2;
                    })
                        .attr("y2", configData.margin.top + configData.title.height);
                };
                O2ChartComponent.prototype.buildGeoOrthographic = function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                    console.log("in buildGeoOrthographic -------------------");
                    _maxX = 100; //any value
                    _maxY = 100; //any value
                    var cdt = new O2Common_1.O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                    var _graphCenterPos = cdt.graphCenterPos;
                    var _titleDisplay = configData.title.display;
                    var _legendDisplay = configData.legend.display;
                    var _focusColor = configData.color.focusColor;
                    var _geoMapDataUrl = dataSetJson.map.baseGeoDataUrl;
                    var _scale = dataSetJson.map.scale;
                    var _targetName = dataSetJson.map.targetName;
                    var _targetProperty = "d." + dataSetJson.map.targetPropertyName;
                    var _keyDataName = dataSetJson.map.keyDataName;
                    var _keyName = "data." + _keyDataName;
                    var _clipAngle = dataSetJson.map.clipAngle;
                    var _rotateH = dataSetJson.map.rotate.horizontal;
                    var _rotateV = dataSetJson.map.rotate.vertical;
                    var _oceanColor = dataSetJson.map.oceanColor;
                    var _antarcticaColor = dataSetJson.map.antarcticaColor;
                    var _animation = configData.animation.enable;
                    var _animationDuration = configData.animation.duration;
                    var _animationH = 0;
                    var _graphCenterPos = cdt.graphCenterPos;
                    var _findColorByName = function (name) {
                        for (var i in dataSetJson.data) {
                            if (name == dataSetJson.data[i].name) {
                                var _color = dataSetJson.data[i].color;
                                return _color;
                            }
                        }
                        return null;
                    };
                    var targetPath = d3.geo.orthographic()
                        .translate(_graphCenterPos)
                        .clipAngle(_clipAngle)
                        .scale(_scale)
                        .rotate([_rotateH, _rotateV]);
                    var path = d3.geo.path()
                        .projection(targetPath);
                    d3.json(_geoMapDataUrl, function (error, data) {
                        svgContainer.append("circle")
                            .attr("cx", _graphCenterPos[0])
                            .attr("cy", _graphCenterPos[1])
                            .attr("r", _scale)
                            .style("fill", _oceanColor);
                        var earthPath = svgContainer.selectAll("path")
                            .data(eval(_keyName))
                            .enter()
                            .append("path")
                            .attr("d", path)
                            .style("fill", function (d, i) {
                            var _targetArea = eval(_targetProperty);
                            if (_findColorByName(_targetArea) != null) {
                                return _findColorByName(_targetArea);
                            }
                            return "hsl(" + i + ",80%,60%)";
                        });
                        if (_animation) {
                            d3.timer(function () {
                                targetPath.rotate([_rotateH + _animationH, _rotateV]);
                                _animationH += 2;
                                earthPath.attr("d", path);
                            });
                        }
                    });
                    //------------------------------------
                    //---CALL buildTitle-----------------
                    if (_titleDisplay) {
                        this.drawTitle(cdt);
                    }
                    if (_legendDisplay) {
                        var _legendDataSet = new Array();
                        for (var i in dataSetJson.data) {
                            var _name = dataSetJson.data[i].name;
                            var _color = dataSetJson.data[i].color;
                            if (_name == "Antarctica") {
                                continue;
                            }
                            _legendDataSet.push(new O2Common_1.O2LegendData(dataSetJson.data[i].name, dataSetJson.data[i].color));
                        }
                        this.buildLegend(cdt, _legendDataSet);
                    }
                };
                O2ChartComponent.prototype.buildGeoMap = function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                    console.log("in buildGeoMap -------------------");
                    _maxX = 100; //any value
                    _maxY = 100; //any value
                    var cdt = new O2Common_1.O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                    var _graphCenterPos = cdt.graphCenterPos;
                    var _geoMapDataUrl = dataSetJson.map.baseGeoDataUrl;
                    var _scale = dataSetJson.map.scale;
                    var _keyDataName = dataSetJson.map.keyDataName;
                    var _keyName = "data." + _keyDataName;
                    var _targetProperty = "d." + dataSetJson.map.targetPropertyName;
                    var _antarcticaColor = dataSetJson.map.antarcticaColor;
                    var _legendDisplay = configData.legend.display;
                    var path = d3.geo.path()
                        .projection(d3.geo.mercator()
                        .translate(_graphCenterPos)
                        .scale(_scale));
                    var _findColorByName = function (name) {
                        for (var i in dataSetJson.data) {
                            if (name == dataSetJson.data[i].name) {
                                var _color = dataSetJson.data[i].color;
                                return _color;
                            }
                        }
                        return null;
                    };
                    d3.json(_geoMapDataUrl, function (error, data) {
                        svgContainer.selectAll("path")
                            .data(eval(_keyName))
                            .enter()
                            .append("path")
                            .attr("d", path)
                            .style("fill", function (d, i) {
                            var _targetArea = eval(_targetProperty);
                            if (_findColorByName(_targetArea) != null) {
                                return _findColorByName(_targetArea);
                            }
                            return "hsl(" + i + ",80%,60%)";
                        });
                    });
                    // ------------------------------------
                    // ---CALL buildLegend-----------------
                    if (_legendDisplay) {
                        var _legendDataSet = new Array();
                        for (var i in dataSetJson.data) {
                            var _name = dataSetJson.data[i].name;
                            var _color = dataSetJson.data[i].color;
                            if (_name == "Antarctica") {
                                continue;
                            }
                            _legendDataSet.push(new O2Common_1.O2LegendData(dataSetJson.data[i].name, dataSetJson.data[i].color));
                        }
                        this.buildLegend(cdt, _legendDataSet);
                    }
                };
                O2ChartComponent.prototype.buildChoropleth = function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                    console.log("in buildChoropleth -------------------");
                    _maxX = 100; //any value
                    _maxY = 100; //any value
                    var cdt = new O2Common_1.O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                    var _graphCenterPos = cdt.graphCenterPos;
                    var _titleDisplay = configData.title.display;
                    var _legendDisplay = configData.legend.display;
                    var _focusColor = configData.color.focusColor;
                    var _scale = dataSetJson.map.scale;
                    var _targetName = dataSetJson.map.targetName;
                    var _keyDataName = dataSetJson.map.keyDataName;
                    var _keyName = "data." + _keyDataName;
                    var _geoMapDataUrl = dataSetJson.map.baseGeoDataUrl;
                    var _startColor = dataSetJson.map.startColor;
                    var _endColor = dataSetJson.map.endColor;
                    var _colorNum = dataSetJson.map.colorNumber;
                    var _center = dataSetJson.map.center;
                    var _targetPropertyName = dataSetJson.map.targetPropertyName;
                    var _targetProperty = "d." + _targetPropertyName;
                    var color = d3.interpolateHsl(_startColor, _endColor);
                    var _max = dataSetJson.data[0].value;
                    var _min = dataSetJson.data[0].value;
                    for (var i in dataSetJson.data) {
                        if (_max < dataSetJson.data[i].value) {
                            _max = dataSetJson.data[i].value;
                        }
                        if (_min > dataSetJson.data[i].value) {
                            _min = dataSetJson.data[i].value;
                        }
                    }
                    var _range = _max - _min;
                    var _step = _range / (_colorNum - 1);
                    var _findColorById = function (id) {
                        for (var i in dataSetJson.data) {
                            if (id == dataSetJson.data[i].id) {
                                var _value = dataSetJson.data[i].value;
                                var _rate = Math.ceil((_value - _min) / _step);
                                return color(_rate / _max);
                            }
                        }
                    };
                    var path = d3.geo.path()
                        .projection(d3.geo.mercator()
                        .center(_center)
                        .scale(_scale)
                        .translate(_graphCenterPos));
                    d3.json(_geoMapDataUrl, function (error, data) {
                        svgContainer.selectAll("path")
                            .data(eval(_keyName))
                            .enter()
                            .append("path")
                            .attr("d", path)
                            .style("fill", function (d, i) {
                            var _cl = _findColorById(eval(_targetProperty));
                            return _cl;
                        });
                    });
                    //------------------------------------
                    //---CALL buildTitle-----------------
                    if (_titleDisplay) {
                        this.drawTitle(cdt);
                    }
                    // ------------------------------------
                    // ---CALL buildLegend-----------------
                    if (_legendDisplay) {
                        var _legendDataSet = new Array();
                        for (var i = 0; i < _colorNum; i++) {
                            var _label = String(_min + (i * _step)) + " --";
                            _legendDataSet.push(new O2Common_1.O2LegendData(_label, color(i / _max)));
                        }
                        this.buildLegend(cdt, _legendDataSet);
                    }
                };
                O2ChartComponent.prototype.buildStackBar = function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                    console.log("in buildStackBar-------------------");
                    var _totalY = new Array();
                    for (var i in dataSetJson.data) {
                        _totalY.push(0);
                    }
                    for (var i in dataSetJson.data) {
                        for (var j in dataSetJson.data[i].value) {
                            _totalY[j] += dataSetJson.data[i].value[j].y;
                        }
                    }
                    var _maxX = 0;
                    var _maxY = 0;
                    _maxY = d3.max(_totalY);
                    _maxX = 100;
                    var cdt = new O2Common_1.O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                    var _color = cdt.defaultColorFunc;
                    var _columnNum = dataSetJson.data.length;
                    var _barWidth = (cdt.graphWidth / _columnNum) - configData.margin.between;
                    var _columnWidth = (cdt.graphWidth / _columnNum);
                    var _initPosX = cdt.graphInitXPos;
                    var _initPosY = cdt.graphInitYPos;
                    var _graphHeight = cdt.graphHeight;
                    var _maxYValue = cdt.maxYValue;
                    var _opacity = configData.color.opacity;
                    var _legendDisplay = configData.legend.display;
                    var _gridYDisplay = configData.grid.y.display;
                    var _gridXDisplay = configData.grid.x.display;
                    var _labelDisplay = configData.label.display;
                    var _animation = configData.animation.enable;
                    var _animationDuration = configData.animation.duration;
                    var _dataArray = new Array();
                    for (var i in dataSetJson.data) {
                        _dataArray.push(dataSetJson.data[i].value);
                    }
                    var yScale = d3.scale.linear()
                        .domain([0, _maxYValue])
                        .range([0, _graphHeight]);
                    var stack = d3.layout.stack()
                        .y(function (d, i) {
                        return d.y;
                    });
                    var _rect = svgContainer.selectAll("g")
                        .data(stack(_dataArray))
                        .enter()
                        .append("g")
                        .attr("fill", function (d, i) {
                        return _color(i);
                    })
                        .attr("fill-opacity", _opacity)
                        .selectAll("rect")
                        .data(function (d, i) {
                        return d;
                    })
                        .enter()
                        .append("rect");
                    if (_animation) {
                        _rect.attr("x", function (d, i) {
                            return _initPosX + i * _columnWidth;
                        })
                            .attr("height", 0)
                            .attr("y", function (d, i) {
                            var _lastY = svgHeight - configData.margin.bottom - yScale(d.y0 + d.y);
                            return _lastY;
                        })
                            .attr("width", _barWidth)
                            .transition()
                            .duration(_animationDuration)
                            .attr("height", function (d, i) {
                            var _yPos = yScale(d.y);
                            return _yPos;
                        });
                    }
                    else {
                        _rect.attr("x", function (d, i) {
                            return _initPosX + i * _columnWidth;
                        })
                            .attr("y", function (d, i) {
                            var _lastY = svgHeight - configData.margin.bottom - yScale(d.y0 + d.y);
                            return _lastY;
                        })
                            .attr("width", _barWidth)
                            .attr("height", function (d, i) {
                            var _yPos = yScale(d.y);
                            return _yPos;
                        });
                    }
                    //------------------------------------
                    //---CALL buildTitle-----------------
                    this.drawTitle(cdt);
                    //------------------------------------
                    //---CALL buildAxis-----------------
                    this.buildYAxis(cdt);
                    this.drawXBaseLine(cdt);
                    // ------------------------------------
                    // ---CALL drawXAxisLabel-----------------
                    if (_labelDisplay) {
                        var _labelArray = new Array();
                        for (var i in dataSetJson.data[0].value) {
                            _labelArray.push(dataSetJson.data[0].value[i].x);
                        }
                        this.drawXAxisLabel(cdt, _labelArray, chartConst_1.ChartConst.STACK_BAR_CHART_TYPE_NAME);
                    }
                    // ------------------------------------
                    // ---CALL buildLegend-----------------
                    if (_legendDisplay) {
                        var _legendDataSet = new Array();
                        for (var i in dataSetJson.data) {
                            _legendDataSet.push(new O2Common_1.O2LegendData(dataSetJson.data[i].name, _color(i)));
                        }
                        this.buildLegend(cdt, _legendDataSet);
                    }
                    if (_gridYDisplay) {
                        this.drawYGrid(cdt);
                    }
                };
                O2ChartComponent.prototype.buildHistogram = function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                    console.log("in buildHistogram-------------------");
                    var dataSet = dataSetJson.data;
                    var histogram = d3.layout.histogram()
                        .range(dataSetJson.range)
                        .bins(dataSetJson.bins);
                    var _maxY = d3.max(histogram(dataSet), function (d, i) {
                        return d.y;
                    });
                    var _maxX = dataSetJson.range[1];
                    var cdt = new O2Common_1.O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                    var _graphWidth = cdt.graphWidth;
                    var _graphHeight = cdt.graphHeight;
                    var _maxYValue = cdt.maxYValue;
                    var _graphXScale = cdt.graphXScale;
                    var _titleDisplay = configData.title.display;
                    var _animation = configData.animation.enable;
                    var _animationDuration = configData.animation.duration;
                    var _gridYDisplay = configData.grid.y.display;
                    var _barWidth = _graphWidth / (dataSetJson.bins.length - 1);
                    var _className = configData.className.histogramBar;
                    var _XScale = d3.scale.linear()
                        .domain([0, _maxX])
                        .range([0, _maxX * _graphXScale]);
                    var yScale = d3.scale.linear()
                        .domain([0, _maxYValue])
                        .range([_graphHeight, 0]);
                    var _rect = svgContainer
                        .selectAll("rect")
                        .data(histogram(dataSet))
                        .enter()
                        .append("rect");
                    if (_animation) {
                        _rect.attr("class", _className)
                            .attr("x", function (d, i) {
                            return i * _barWidth + configData.margin.left;
                        })
                            .attr("y", function (d, i) {
                            var _yPos = yScale(d.y)
                                + configData.margin.top
                                + configData.title.height;
                            return _yPos;
                        })
                            .attr("height", 0)
                            .attr("width", _barWidth)
                            .transition()
                            .duration(_animationDuration)
                            .attr("height", function (d, i) {
                            return _graphHeight - yScale(d.y);
                        });
                    }
                    else {
                        _rect.attr("class", _className)
                            .attr("x", function (d, i) {
                            return i * _barWidth + configData.margin.left;
                        })
                            .attr("y", function (d, i) {
                            var _yPos = yScale(d.y)
                                + configData.margin.top
                                + configData.title.height;
                            return _yPos;
                        })
                            .attr("width", _barWidth)
                            .attr("height", function (d, i) {
                            return _graphHeight - yScale(d.y);
                        });
                    }
                    //---CALL buildTitle-----------------
                    if (_titleDisplay) {
                        this.drawTitle(cdt);
                    }
                    //------------------------------------
                    //---CALL buildAxis-----------------
                    this.buildYAxis(cdt);
                    this.buildXAxis(cdt);
                    if (_gridYDisplay) {
                        this.drawYGrid(cdt);
                    }
                };
                O2ChartComponent.prototype.buildScatterPlot = function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                    console.log("In  buildScatterPlot----------------");
                    var _dataSet = new Array();
                    var _maxX = 0;
                    var _maxY = 0;
                    for (var i in dataSetJson.data) {
                        for (var j in dataSetJson.data[i].value) {
                            if (_maxX < dataSetJson.data[i].value[j].x) {
                                _maxX = dataSetJson.data[i].value[j].x;
                            }
                            if (_maxY < dataSetJson.data[i].value[j].y) {
                                _maxY = dataSetJson.data[i].value[j].y;
                            }
                            var _scatterPlotData = new O2Common_1.O2ScatterPlotData(dataSetJson.data[i].value[j].x, dataSetJson.data[i].value[j].y, dataSetJson.data[i].value[j].r);
                            _dataSet.push(_scatterPlotData);
                        }
                    }
                    var cdt = new O2Common_1.O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                    var _initPosX = cdt.graphInitXPos;
                    var _initPosY = cdt.graphInitYPos;
                    var _seriesNumber = dataSetJson.series.length;
                    var _color = cdt.defaultColorFunc;
                    var _opacity = configData.color.opacity;
                    var _gridYDisplay = configData.grid.y.display;
                    var _gridXDisplay = configData.grid.x.display;
                    var _titleDisplay = configData.title.display;
                    var _legendDisplay = configData.legend.display;
                    var _circle = svgContainer.selectAll("circle")
                        .data(_dataSet)
                        .enter()
                        .append("circle")
                        .attr("cx", function (d, i) {
                        return _initPosX + d.x;
                    })
                        .attr("cy", function (d, i) {
                        return (svgHeight - configData.margin.bottom - d.y);
                    })
                        .attr("r", function (d, i) {
                        return d.r;
                    })
                        .style("fill", function (d, i) {
                        var _colorNum = i % _seriesNumber;
                        return _color(_colorNum);
                    })
                        .attr("fill-opacity", _opacity);
                    //---CALL buildTitle-----------------
                    if (_titleDisplay) {
                        this.drawTitle(cdt);
                    }
                    //------------------------------------
                    //---CALL buildLegend-----------------
                    if (_legendDisplay) {
                        var _legendDataSet = new Array();
                        for (var i = 0; i < dataSetJson.series.length; i++) {
                            _legendDataSet.push(new O2Common_1.O2LegendData(dataSetJson.series[i], _color(i)));
                        }
                        this.buildLegend(cdt, _legendDataSet);
                    }
                    //------------------------------------
                    //---CALL buildAxis-----------------
                    this.buildYAxis(cdt);
                    this.buildXAxis(cdt);
                    if (_gridYDisplay) {
                        this.drawYGrid(cdt);
                    }
                    if (_gridXDisplay) {
                        this.drawXGrid(cdt);
                        ;
                    }
                };
                O2ChartComponent.prototype.buildPie = function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                    console.log("In  buildPie----------------");
                    var _maxX = 0;
                    var _maxY = 0;
                    _maxY = 100;
                    _maxX = 100;
                    var cdt = new O2Common_1.O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                    var _color = cdt.defaultColorFunc;
                    var _initPosX = cdt.graphInitXPos;
                    var _initPosY = cdt.graphInitYPos;
                    var _graphHeight = cdt.graphHeight;
                    var _graphWidth = cdt.graphWidth;
                    var _opacity = configData.color.opacity;
                    var _titleHeight = configData.title.height;
                    var _leftMargin = configData.margin.left;
                    var _topMargin = configData.margin.top;
                    var _bottomMargin = configData.margin.bottom;
                    var _betweenMargin = configData.margin.between;
                    var _innerRadiusPercent = cdt.innerRadiusPercent;
                    var _graphCenterTranslatePos = cdt.graphCenterTranslatePos;
                    var _pieClassName = configData.className.pie;
                    var _pieValueClassName = configData.className.pieNum;
                    var _pieInnerTitleClassName = configData.className.pieInnerTitle;
                    var _innerRadiusTitleTranslatePos = cdt.innerRadiusTitleTranslatePos;
                    var _innerRadiusTitle = cdt.innerRadiusTitle;
                    var _titleDisplay = configData.title.display;
                    var _legendDisplay = configData.legend.display;
                    var _labelDisplay = configData.label.display;
                    var _valueDisplay = configData.pie.value.display;
                    var _percentDisplay = configData.pie.percent.display;
                    var _animation = configData.animation.enable;
                    var _animationDuration = configData.animation.duration;
                    var width = svgWidth;
                    var height = svgHeight;
                    var dataSet = new Array();
                    for (var i in dataSetJson.data) {
                        var _num = dataSetJson.data[i].value;
                        dataSet.push(_num);
                    }
                    var _sum = d3.sum(dataSet);
                    var pie = d3.layout.pie();
                    var arc = d3.svg.arc()
                        .innerRadius(_graphHeight * _innerRadiusPercent / 100)
                        .outerRadius(_graphHeight / 2);
                    var pieElements = svgContainer.selectAll("path")
                        .data(pie(dataSet))
                        .enter()
                        .append("g")
                        .attr("transform", _graphCenterTranslatePos);
                    var _makeCenterTitle = function () {
                        if (_valueDisplay && _percentDisplay) {
                            var _st = _innerRadiusTitle + ":" + _sum + " (100%)";
                            return _st;
                        }
                        if (_percentDisplay) {
                            return "100%";
                        }
                        if (_valueDisplay) {
                            return _innerRadiusTitle + ":" + _sum;
                        }
                    };
                    var textElements = svgContainer.append("text")
                        .attr("class", _pieInnerTitleClassName)
                        .attr("transform", _innerRadiusTitleTranslatePos)
                        .text(_makeCenterTitle);
                    var _arc = pieElements.append("path")
                        .attr("class", _pieClassName)
                        .style("fill", function (d, i) {
                        return _color(i);
                    })
                        .attr("fill-opacity", _opacity);
                    if (_animation) {
                        _arc.transition()
                            .duration(_animationDuration)
                            .delay(function (d, i) {
                            return i * 1000;
                        })
                            .attrTween("d", function (d, i) {
                            var _interpolate = d3.interpolate({ startAngle: d.startAngle, endAngle: d.startAngle }, { startAngle: d.startAngle, endAngle: d.endAngle });
                            return function (t) {
                                return arc(_interpolate(t));
                            };
                        });
                    }
                    else {
                        _arc.attr("d", arc);
                    }
                    pieElements.append("text")
                        .attr("class", _pieValueClassName)
                        .attr("transform", function (d, i) {
                        return "translate(" + arc.centroid(d) + ")";
                    })
                        .text(function (d, i) {
                        if (_valueDisplay && _percentDisplay) {
                            var _percentSt = String(Math.ceil(d.value / _sum * 100));
                            var _st = String(d.value) + " (" + _percentSt + "%)";
                            return _st;
                        }
                        if (_percentDisplay) {
                            var _percentSt = String(Math.ceil(d.value / _sum * 100));
                            var _st = _percentSt + "%";
                            return _st;
                        }
                        if (_valueDisplay) {
                            return d.value;
                        }
                    });
                    //---CALL buildTitle-----------------
                    if (_titleDisplay) {
                        this.drawTitle(cdt);
                    }
                    //------------------------------------
                    //---CALL buildLegend-----------------
                    if (_legendDisplay) {
                        var _legendDataSet = new Array();
                        for (var i in dataSetJson.data) {
                            _legendDataSet.push(new O2Common_1.O2LegendData(dataSetJson.data[i].name, _color(i)));
                        }
                        this.buildLegend(cdt, _legendDataSet);
                    }
                };
                O2ChartComponent.prototype.buildBar = function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                    console.log("In  buildBar----------------");
                    var _yDataSet = new Array();
                    for (var i in dataSetJson.data) {
                        for (var j in dataSetJson.data[i].y) {
                            var _y = dataSetJson.data[i].y[j];
                            _yDataSet.push(_y);
                        }
                    }
                    var _maxX = 0;
                    var _maxY = 0;
                    _maxY = d3.max(_yDataSet);
                    _maxX = 100;
                    var cdt = new O2Common_1.O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                    var _barValueClass = configData.className.barValue;
                    var _color = cdt.defaultColorFunc;
                    var _seriesNum = dataSetJson.series.length;
                    var _columnNum = _yDataSet.length;
                    var _initPosX = cdt.graphInitXPos;
                    var _initPosY = cdt.graphInitYPos;
                    var _graphHeight = cdt.graphHeight;
                    var _graphWidth = cdt.graphWidth;
                    var _maxYValue = cdt.maxYValue;
                    var _opacity = configData.color.opacity;
                    var _titleHeight = configData.title.height;
                    var _titleDisplay = configData.title.display;
                    var _leftMargin = configData.margin.left;
                    var _topMargin = configData.margin.top;
                    var _bottomMargin = configData.margin.bottom;
                    var _betweenMargin = configData.margin.between;
                    var _legendDisplay = configData.legend.display;
                    var _labelDisplay = configData.label.display;
                    var _gridYDisplay = configData.grid.y.display;
                    var _animation = configData.animation.enable;
                    var _animationDuration = configData.animation.duration;
                    var _barWidth = (_graphWidth - (_betweenMargin * _columnNum / _seriesNum)) / _columnNum;
                    var _columnWidth = (_graphWidth / _columnNum);
                    var _graphYScale = cdt.graphYScale;
                    var yBarScale = d3.scale.linear()
                        .domain([0, _maxY])
                        .range([_maxY * _graphYScale, 0]);
                    var _barPadding = _betweenMargin;
                    var grpGraph = svgContainer.selectAll("g")
                        .data(_yDataSet)
                        .enter()
                        .append("g")
                        .attr("transform", function (d, i) {
                        var _padding = ((i % _seriesNum) == 0) ? _barPadding : 0;
                        return "translate(" + (_padding + _columnWidth * i) + ")";
                    })
                        .style("fill", function (d, i) {
                        var _remnant = (i % _seriesNum);
                        return _color(_remnant);
                    })
                        .attr("fill-opacity", _opacity);
                    var _rect = grpGraph.append("rect");
                    if (_animation) {
                        _rect.attr("x", _leftMargin)
                            .attr("height", 0)
                            .attr("y", function (d) {
                            return _initPosY;
                        })
                            .attr("width", _barWidth - _barPadding)
                            .transition()
                            .duration(_animationDuration)
                            .attr("y", function (d) {
                            return yBarScale(d) + _initPosY;
                        })
                            .attr("height", function (d) {
                            return _graphHeight - yBarScale(d);
                        });
                    }
                    else {
                        _rect.attr("x", _leftMargin)
                            .attr("y", function (d) {
                            return yBarScale(d) + _initPosY;
                        })
                            .attr("width", _barWidth - _barPadding)
                            .attr("height", function (d) {
                            return _graphHeight - yBarScale(d);
                        });
                    }
                    var textBarValue = grpGraph.append("text");
                    textBarValue
                        .attr("class", _barValueClass)
                        .attr("x", _leftMargin)
                        .attr("y", function (d) {
                        return yBarScale(d) + _initPosY;
                    })
                        .text(function (d) { return d; });
                    //------------------------------------
                    //---CALL buildAxis-----------------
                    this.buildYAxis(cdt);
                    // ------------------------------------
                    // ---CALL drawXAxisLabel-----------------
                    if (_labelDisplay) {
                        var _labelArray = new Array();
                        for (var i in dataSetJson.data) {
                            _labelArray.push(dataSetJson.data[i].x);
                        }
                        this.drawXAxisLabel(cdt, _labelArray, chartConst_1.ChartConst.BAR_CHART_TYPE_NAME);
                    }
                    this.drawXBaseLine(cdt);
                    // ------------------------------------
                    // ---CALL buildLegend-----------------
                    var _legendDataSet = new Array();
                    for (var i in dataSetJson.series) {
                        _legendDataSet.push(new O2Common_1.O2LegendData(dataSetJson.series[i], _color(i)));
                    }
                    this.buildLegend(cdt, _legendDataSet);
                    //------------------------------------
                    //---CALL buildTitle-----------------
                    if (_titleDisplay) {
                        this.drawTitle(cdt);
                    }
                    if (_gridYDisplay) {
                        this.drawYGrid(cdt);
                    }
                };
                O2ChartComponent.prototype.buildPackLayout = function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                    var _packlayoutClass = configData.className.packlayout;
                    var _packlayoutLabelClass = configData.className.packlayoutLabel;
                    var _animation = configData.animation.enable;
                    var _animationDuration = configData.animation.duration;
                    var color = d3.scale.category10();
                    var bubble = d3.layout.pack()
                        .size([svgWidth, svgHeight]);
                    var pack = svgContainer.selectAll("g")
                        .data(bubble.nodes(dataSetJson))
                        .enter()
                        .append("g")
                        .attr("transform", function (d, i) {
                        return "translate(" + d.x + "," + d.y + ")";
                    });
                    var _circle = pack.append("circle");
                    if (_animation) {
                        _circle.attr("r", 0)
                            .transition()
                            .duration(function (d, i) {
                            return d.depth * _animationDuration + 500;
                        })
                            .attr("r", function (d) {
                            return d.r;
                        })
                            .style("fill", function (d, i) {
                            return color(i);
                        });
                    }
                    else {
                        _circle.attr("r", function (d) {
                            return d.r;
                        })
                            .style("fill", function (d, i) {
                            return color(i);
                        });
                    }
                    var _text = pack.append("text")
                        .attr("class", _packlayoutLabelClass)
                        .text(function (d, i) {
                        if (d.depth == 1) {
                            return d.name;
                        }
                        return null;
                    });
                    if (_animation) {
                        _text.style("opacity", 0)
                            .transition()
                            .duration(_animationDuration)
                            .style("opacity", 1.0);
                    }
                    else {
                        _text.style("opacity", 1.0);
                    }
                };
                O2ChartComponent.prototype.buildTreeMap = function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                    console.log("In  buildBar----------------");
                    var _animation = configData.animation.enable;
                    var _animationDuration = configData.animation.duration;
                    var _treemapClass = configData.className.treemap;
                    var _treemapLabelClass = configData.className.treemapLabel;
                    var treemap = d3.layout.treemap()
                        .size([svgWidth, svgHeight]);
                    var tmap = svgContainer.selectAll("rect")
                        .data(treemap.nodes(dataSetJson));
                    tmap.enter()
                        .append("rect")
                        .attr("class", _treemapClass)
                        .attr("x", function (d, i) {
                        return d.x;
                    })
                        .attr("y", function (d, i) {
                        return d.y;
                    })
                        .attr("width", function (d, i) {
                        return d.dx;
                    })
                        .attr("height", function (d, i) {
                        return d.dy;
                    });
                    if (_animation) {
                        tmap.style("opacity", 0)
                            .transition()
                            .delay(function (d, i) {
                            return d.depth * 500;
                        })
                            .style("opacity", function (d, i) {
                            return d.depth / 10;
                        });
                    }
                    else {
                        tmap.style("opacity", 0)
                            .style("opacity", function (d, i) {
                            return d.depth / 10;
                        });
                    }
                    tmap.enter()
                        .append("text")
                        .attr("class", _treemapLabelClass)
                        .attr("transform", function (d, i) {
                        return "translate(" + (d.x + d.dx / 2) + "," + (d.y + d.dy / 2) + ") ";
                    })
                        .attr("dy", "0.35em")
                        .text(function (d, i) {
                        if ((d.depth == 0) || (d.children)) {
                            return null;
                        }
                        return d.name + "  (" + d.value + ")";
                    });
                };
                O2ChartComponent.prototype.buildLine = function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                    console.log("in buildLine-------------------");
                    var _groupMaxY = new Array();
                    for (var i in dataSetJson.data) {
                        var _gMaxY = 0;
                        for (var j in dataSetJson.data[i].value) {
                            if (_gMaxY < dataSetJson.data[i].value[j].y) {
                                _gMaxY = dataSetJson.data[i].value[j].y;
                            }
                        }
                        _groupMaxY.push(_gMaxY);
                    }
                    var _maxX = 0;
                    var _maxY = 0;
                    _maxY = d3.max(_groupMaxY);
                    _maxX = 100;
                    var cdt = new O2Common_1.O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                    var _color = cdt.defaultColorFunc;
                    var _columnNum = dataSetJson.data[0].value.length;
                    var _columnWidth = cdt.graphWidth / _columnNum;
                    if (configData.grid.y.display) {
                        this.drawYGrid(cdt);
                    }
                    for (var i in dataSetJson.data) {
                        var _lineArray = new Array();
                        for (var j in dataSetJson.data[i].value) {
                            _lineArray.push(dataSetJson.data[i].value[j].y);
                        }
                        this.drawSingleLine(cdt, _lineArray, i);
                    }
                    //------------------------------------
                    //---CALL buildTitle-----------------
                    this.drawTitle(cdt);
                    //------------------------------------
                    //---CALL buildAxis-----------------
                    this.buildYAxis(cdt);
                    this.drawXBaseLine(cdt);
                    // ------------------------------------
                    // ---CALL drawXAxisLabel-----------------
                    var _labelArray = new Array();
                    for (var i in dataSetJson.data[0].value) {
                        _labelArray.push(dataSetJson.data[0].value[i].x);
                    }
                    this.drawXAxisLabel(cdt, _labelArray, chartConst_1.ChartConst.LINE_CHART_TYPE_NAME);
                    // ------------------------------------
                    // ---CALL buildLegend-----------------
                    var _legendDataSet = new Array();
                    for (var i in dataSetJson.data) {
                        _legendDataSet.push(new O2Common_1.O2LegendData(dataSetJson.data[i].name, _color(i)));
                    }
                    this.buildLegend(cdt, _legendDataSet);
                };
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', String)
                ], O2ChartComponent.prototype, "chartType", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', String)
                ], O2ChartComponent.prototype, "svgWidth", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', String)
                ], O2ChartComponent.prototype, "svgHeight", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Array)
                ], O2ChartComponent.prototype, "graphData", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Object)
                ], O2ChartComponent.prototype, "configData", void 0);
                O2ChartComponent = __decorate([
                    core_1.Directive({
                        selector: 'o2-chart'
                    }),
                    __param(0, core_1.Inject(core_1.ElementRef)), 
                    __metadata('design:paramtypes', [core_1.ElementRef])
                ], O2ChartComponent);
                return O2ChartComponent;
            })();
            exports_1("O2ChartComponent", O2ChartComponent);
        }
    }
});
//# sourceMappingURL=O2Chart.component.js.map