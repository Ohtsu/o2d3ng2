System.register([], function(exports_1) {
    var ChartConst;
    return {
        setters:[],
        execute: function() {
            ChartConst = (function () {
                function ChartConst() {
                }
                ChartConst.LINE_CHART_TYPE_NAME = "line";
                ChartConst.BAR_CHART_TYPE_NAME = "bar";
                ChartConst.PIE_CHART_TYPE_NAME = "pie";
                ChartConst.SCATTER_PLOT_CHART_TYPE_NAME = "scatterPlot";
                ChartConst.HISTOGRAM_CHART_TYPE_NAME = "histogram";
                ChartConst.STACK_BAR_CHART_TYPE_NAME = "stackBar";
                ChartConst.GEO_MAP_CHART_TYPE_NAME = "geoMap";
                ChartConst.GEO_ORTHOGRAPHIC_CHART_TYPE_NAME = "geoOrthographic";
                ChartConst.TREE_MAP_CHART_TYPE_NAME = "treeMap";
                ChartConst.PACK_LAYOUT_CHART_TYPE_NAME = "packLayout";
                ChartConst.CHOROPLETH_CHART_TYPE_NAME = "choropleth";
                return ChartConst;
            })();
            exports_1("ChartConst", ChartConst);
        }
    }
});
//# sourceMappingURL=chartConst.js.map