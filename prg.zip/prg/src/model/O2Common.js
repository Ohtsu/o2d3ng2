System.register([], function(exports_1) {
    var O2Common, O2LineData, O2LegendData, O2ScatterPlotData, O2StackBarData, O2IdValueData;
    return {
        setters:[],
        execute: function() {
            O2Common = (function () {
                function O2Common(svgContainer, configData, autoMaxX, autoMaxY, svgWidth, svgHeight) {
                    this.svgContainer = svgContainer;
                    this.configData = configData;
                    this.autoMaxX = autoMaxX;
                    this.autoMaxY = autoMaxY;
                    this.svgWidth = svgWidth;
                    this.svgHeight = svgHeight;
                }
                Object.defineProperty(O2Common.prototype, "axisClassName", {
                    // -------------------------------------------
                    // ----  CLASS NAME  -------------------------
                    // -------------------------------------------
                    get: function () {
                        return this.configData.className.axis;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "lineClassName", {
                    get: function () {
                        return this.configData.className.line;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "axisXBorderLineClassName", {
                    get: function () {
                        return this.configData.className.axisXBorder;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "maxXValue", {
                    // -------------------------------------------
                    // ----  MAX VALUE  --------------------------
                    // -------------------------------------------
                    get: function () {
                        var _maxX = this.autoMaxX;
                        if (!this.configData.maxValue.auto) {
                            _maxX = this.configData.maxValue.x;
                        }
                        return _maxX;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "maxYValue", {
                    get: function () {
                        var _maxY = this.autoMaxY;
                        if (!this.configData.maxValue.auto) {
                            _maxY = this.configData.maxValue.y;
                        }
                        return _maxY;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "graphInitXPos", {
                    // -------------------------------------------
                    // ----  GRAPH -------------------------------
                    // -------------------------------------------
                    get: function () {
                        var _intX = this.configData.margin.left;
                        if (this.configData.legend.display && this.configData.legend.position != "right") {
                            _intX = this.configData.margin.left
                                + this.configData.legend.totalWidth;
                        }
                        return _intX;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "graphInitYPos", {
                    get: function () {
                        var _intY = this.configData.margin.top
                            + this.configData.title.height;
                        return _intY;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "graphYScale", {
                    get: function () {
                        return this.graphHeight / this.maxYValue;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "graphXScale", {
                    get: function () {
                        return this.graphWidth / this.maxXValue;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "graphWidth", {
                    get: function () {
                        var _margin = this.configData.margin.left
                            + this.configData.margin.right;
                        if (this.configData.legend.display) {
                            _margin += this.configData.legend.totalWidth;
                        }
                        return this.svgWidth - _margin;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "graphHeight", {
                    get: function () {
                        var _h = this.svgHeight
                            - this.configData.title.height
                            - this.configData.margin.top
                            - this.configData.margin.bottom;
                        return _h;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "graphCenterPos", {
                    get: function () {
                        var _xyArray = new Array();
                        var _x = this.configData.margin.left
                            + this.graphWidth / 2;
                        var _y = this.configData.margin.top
                            + this.configData.title.height
                            + this.graphHeight / 2;
                        _xyArray.push(_x);
                        _xyArray.push(_y);
                        return _xyArray;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "graphCenterTranslatePos", {
                    get: function () {
                        var _x = this.configData.margin.left
                            + this.graphWidth / 2;
                        var _y = this.configData.margin.top
                            + this.configData.title.height
                            + this.graphHeight / 2;
                        return "translate(" + String(_x) + ", " + String(_y) + ")";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "graphInitTranslatePos", {
                    get: function () {
                        var _x = this.graphInitXPos;
                        var _y = this.graphInitYPos;
                        return "translate(" + String(_x) + ", " + String(_y) + ")";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "axisXLabelInitXPos", {
                    // -------------------------------------------
                    // ----  AXIS  -------------------------------
                    // -------------------------------------------
                    get: function () {
                        var _x = this.configData.margin.left
                            + this.configData.axis.xLabel.leftMargin;
                        return _x;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "axisXLabelInitYPos", {
                    get: function () {
                        var _y = this.svgHeight
                            - this.configData.axis.xLabel.bottomMargin;
                        return _y;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "axisTranslatePos", {
                    get: function () {
                        var _x = this.configData.margin.left;
                        var _y = this.configData.margin.top
                            + this.configData.title.height;
                        return "translate(" + String(_x) + ", " + String(_y) + ")";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "axisXBorderLineWidth", {
                    get: function () {
                        return this.configData.axis.borderLineWidth;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "axisYBorderHeight", {
                    get: function () {
                        var _margin = this.configData.margin.top
                            + this.configData.margin.bottom
                            + this.configData.title.height;
                        return this.svgHeight - _margin;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "axisXBorderWidth", {
                    get: function () {
                        var _margin = this.configData.margin.left
                            + this.configData.margin.right;
                        if (this.configData.legend.display) {
                            _margin += this.configData.legend.totalWidth;
                        }
                        return this.svgWidth - _margin;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "axisYOrient", {
                    get: function () {
                        return "left";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "axisXOrient", {
                    get: function () {
                        return "bottom";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "axisXBorderTranslatePos", {
                    get: function () {
                        var sYpos = String(this.svgHeight - this.configData.margin.bottom);
                        return "translate(" + this.configData.margin.left + ", " + sYpos + ")";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "innerRadiusPercent", {
                    // -------------------------------------------
                    // ----  RADIUS  -------------------------------
                    // -------------------------------------------
                    get: function () {
                        return this.configData.pie.innerRadius.percent;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "innerRadiusTitle", {
                    get: function () {
                        return this.configData.pie.innerRadius.title;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "innerRadiusTitleTranslatePos", {
                    get: function () {
                        var _x = this.configData.margin.left
                            + this.graphWidth / 2;
                        var _y = this.configData.margin.top
                            + this.configData.title.height
                            + this.graphHeight / 2
                            + 5;
                        return "translate(" + String(_x) + ", " + String(_y) + ")";
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "legendInitXPos", {
                    // -------------------------------------------
                    // ----  LEGEND  -------------------------------
                    // -------------------------------------------
                    get: function () {
                        var _x = this.configData.margin.left
                            + this.graphWidth
                            + this.configData.legend.initXPos;
                        if (this.configData.legend.position != "right") {
                            _x = this.configData.margin.left
                                + this.configData.legend.initXPos;
                        }
                        return _x;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "legendInitYPos", {
                    get: function () {
                        var _y = this.configData.margin.top
                            + this.configData.title.height
                            + this.configData.legend.initYPos;
                        return _y;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "gridYStep", {
                    // -------------------------------------------
                    // ----  GRID  -------------------------------
                    // -------------------------------------------
                    get: function () {
                        var _maxY = Math.ceil(this.maxYValue / 100) * 10;
                        var _lineNum = 10;
                        var _step = Math.ceil(_maxY / _lineNum) * _lineNum;
                        return _step;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "gridXStep", {
                    get: function () {
                        var _maxX = Math.ceil(this.maxXValue / 100) * 10;
                        var _lineNum = 10;
                        var _step = Math.ceil(_maxX / _lineNum) * _lineNum;
                        return _step;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "titleInitXPos", {
                    // -------------------------------------------
                    // ----  TITLE  -------------------------------
                    // -------------------------------------------
                    get: function () {
                        var _x = this.configData.margin.left
                            + (this.graphWidth + this.configData.legend.totalWidth) / 2
                            + this.configData.title.leftMargin;
                        return _x;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "titleInitYPos", {
                    get: function () {
                        var _y = this.configData.margin.top
                            + this.configData.title.height
                            - this.configData.title.bottomMargin;
                        return _y;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(O2Common.prototype, "defaultColorFunc", {
                    // -------------------------------------------
                    // ----  COLOR  -------------------------------
                    // -------------------------------------------
                    get: function () {
                        var _color;
                        if (this.configData.color.auto) {
                            if (this.configData.color.defaultColorNumber == "20") {
                                _color = d3.scale.category20();
                            }
                            else {
                                _color = d3.scale.category10();
                            }
                        }
                        return _color;
                    },
                    enumerable: true,
                    configurable: true
                });
                return O2Common;
            })();
            exports_1("O2Common", O2Common);
            O2LineData = (function () {
                function O2LineData(data, color, dashedArray, interpolate) {
                    this.data = data;
                    this.color = color;
                    this.dashedArray = dashedArray;
                    this.interpolate = interpolate;
                }
                return O2LineData;
            })();
            exports_1("O2LineData", O2LineData);
            O2LegendData = (function () {
                function O2LegendData(title, color) {
                    this.title = title;
                    this.color = color;
                }
                return O2LegendData;
            })();
            exports_1("O2LegendData", O2LegendData);
            O2ScatterPlotData = (function () {
                function O2ScatterPlotData(x, y, r) {
                    this.x = x;
                    this.y = y;
                    this.r = r;
                }
                return O2ScatterPlotData;
            })();
            exports_1("O2ScatterPlotData", O2ScatterPlotData);
            O2StackBarData = (function () {
                function O2StackBarData(x, y) {
                    this.x = x;
                    this.y = y;
                }
                return O2StackBarData;
            })();
            exports_1("O2StackBarData", O2StackBarData);
            O2IdValueData = (function () {
                function O2IdValueData(id, value) {
                    this.id = id;
                    this.value = value;
                }
                return O2IdValueData;
            })();
            exports_1("O2IdValueData", O2IdValueData);
        }
    }
});
//# sourceMappingURL=O2Common.js.map